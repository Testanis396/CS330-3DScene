﻿#include <glad/glad.h>
#include <GLFW/glfw3.h>

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "shader.h"
#include "camera.h"

#include <iostream>

/*
 * Tomas Estanislao
 * CS330
 * 7-1 Final Project
 * 
 * Created sphere to represent ball object. 6 circles: 2 bases + 4 faces.
 * Created torus to represent keychain loop on top of sphere. 6 rings.
 * Created additional books and added extra vertices to wrap extra textures
 * for back cover and spine.
 * 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * 
 * Updated milestone 5 code with assignment 6 code
 * Working on old texture shadercode for book object to display a more matte finish. 
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * 
 * Updated milestone 4 code with assignment 5 code
 * Source code used from learnopengl 4.2.textures_combined.
 * Used tutorial 5_5 code for mixing textures (added boolean for multiple).
 * Added alpha value to color attributes for transparency.
 * Added cylinders for complex object and candle.
 * Added extra vertices to objects for wrapping.
 * Book is there for reference, will later add more textures for pages and sides.
 * 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * 
 * Updated milestone 3 code with assignment 4 code
 * Assignement 4 source code from learnopengl 7.2.camera_keyboard_dt
 * and 7.3.camera_mouse_zoom.
 * 
 * Referenced OpenGLSample to implement camera.h.
 * Added QE and Mouse Scroll functionality to camera.h
 * 
 * The following functionality is implemented:
 * WASD keys: These keys should be used to control the forward, backward, left, and right motion.
 * QE keys: These keys should be used to control the upward and downward movement.
 * P key: This key should be used to switch between orthographic (2D) and perspective (3D) views at will.
 * Mouse cursor: This should be used to change the orientation of the camera so it can look up and down or right and left.
 * Mouse scroll: This should be used to adjust the speed of the movement, or the speed the camera travels around the scene.
 * 
 * Adjusted table and book transformations in addition to camera implementation.
 * 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * 
 * Updated assignment 3 code to make hexagonal prism instead of pyramid.
 * Added elongated cube for book, and trapezoidal prism for stand.
 * Added plane to stand, solar panels. 
 * Added plane for end table.
 * 
 * Need to investigate cylinder and sphere code.
 * Found http://www.songho.ca/opengl/gl_cylinder.html
 * 
 * Need to investigate mesh/classes/functions/unifying.
 * Modularize code.
 * 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *
 * Source code used from learnopengl 6.2.coordinate_systems_depth.
 * Changed vertex.vs and frag.fs to use colors instead of textures.
 *
 * Vertices stored in vertices array with 3 coordinates (x,y,z)
 * followed by vertex color (r,g,b).
 * 
 * Triangles stored in indices element array (e1,e2,e3).
 * 
 * Wireframe mode available before rendering.
 * 
 * Each object renders seperately.

 */

void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);
void processInput(GLFWwindow* window);
unsigned int loadTexture(const char* path);

// settings
const unsigned int SCR_WIDTH = 800;
const unsigned int SCR_HEIGHT = 600;

// camera
Camera camera(glm::vec3(0.0f, 2.0f, 4.0f));
bool firstMouse = true;
bool isPerspective = true; // Start with perspective projection
bool multiple = true;
float lastX = SCR_WIDTH / 2.0;
float lastY = SCR_HEIGHT / 2.0;

// timing
float deltaTime = 0.0f;	// time between current frame and last frame
float lastFrame = 0.0f;

// lighting
glm::vec2 uvScale(1.0f, 1.0f);

int main()
{
    // glfw: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // glfw window creation
    // --------------------
    GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "Tomas Estanislao 7-1: Final Project", NULL, NULL);
    if (window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
    glfwSetCursorPosCallback(window, mouse_callback);
    glfwSetScrollCallback(window, scroll_callback);

    // tell GLFW to capture our mouse
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_NORMAL);

    // glad: load all OpenGL function pointers
    // ---------------------------------------
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
    {
        std::cout << "Failed to initialize GLAD" << std::endl;
        return -1;
    }

    // configure global opengl state
    // -----------------------------
    glEnable(GL_DEPTH_TEST);

    // Enable blending
    // -----------------------------
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    // build and compile our shader's
    // ------------------------------------
    Shader ourShader("vertex.vs", "frag.fs");
    Shader lightShader("light.vs", "light.fs");

    // set up vertex data (and buffer(s)) and configure vertex attributes
    // ------------------------------------------------------------------

    // define hexagonal prism vertices and indices
    float alpha = 0.5f;
    
    float vertices[] = {
        // positions                                       // color rgba            // tex coords
        // 
        // top hexagon (y = .5f)
        (sqrt(3.0f) / 2.0f) / 1.5f, 0.5f, (0.5f / 1.5f),   1.0f, 0.5f, 1.0f, alpha,  0.0, 0.0,  // vertex 0
        (sqrt(3.0f) / 2.0f) / 1.5f, 0.5f, (-0.5f / 1.5f),  0.5f, 1.0f, 1.0f, alpha,  1.0, 0.0,  // vertex 1
        0.0f, 0.5f, (-1.0f / 1.5f),                        1.0f, 1.0f, 0.5f, alpha,  0.0, 0.0,  // vertex 2
        (-sqrt(3.0f) / 2.0f) / 1.5f, 0.5f, (-0.5f / 1.5f), 1.0f, 0.5f, 1.0f, alpha,  1.0, 0.0,  // vertex 3
        (-sqrt(3.0f) / 2.0f) / 1.5f, 0.5f, (0.5f / 1.5f),  0.5f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 4
        0.0f, 0.5f, (1.0f / 1.5f),                         1.0f, 1.0f, 0.5f, alpha,  1.0, 0.0,  // vertex 5

        // bottom hexagon (y = -.5f)
        (sqrt(3.0f) / 2.0f), -0.5f, 0.5f,                  0.5f, 1.0f, 1.0f, alpha,  0.0, 1.0,  // vertex 6
        (sqrt(3.0f) / 2.0f), -0.5f, -0.5f,                 1.0f, 0.5f, 1.0f, alpha,  1.0, 1.0,  // vertex 7
        0.0f, -0.5f, -1.0f,                                1.0f, 1.0f, 0.5f, alpha,  0.0, 1.0,  // vertex 8
        (-sqrt(3.0f) / 2.0f), -0.5f, -0.5f,                0.5f, 1.0f, 1.0f, alpha,  1.0, 1.0,  // vertex 9
        (-sqrt(3.0f) / 2.0f), -0.5f, 0.5f,                 1.0f, 0.5f, 1.0f, alpha,  0.0, 1.0,  // vertex 10
        0.0f, -0.5f, 1.0f,                                 1.0f, 1.0f, 0.5f, alpha,  1.0, 1.0,  // vertex 11

        // top vertex
        0.0f, 0.5f, 0.0f,                                  1.0f, 1.0f, 1.0f, alpha,  0.5, 0.5,  // vertex 12

        // bottom vertex
        0.0f, -0.5f, 0.0f,                                 1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 13

        // extra vertices for bottom base texture
        (sqrt(3.0f) / 2.0f), -0.5f, 0.5f,                  0.5f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 14
        (sqrt(3.0f) / 2.0f), -0.5f, -0.5f,                 1.0f, 0.5f, 1.0f, alpha,  0.0, 0.0,  // vertex 15
        0.0f, -0.5f, -1.0f,                                1.0f, 1.0f, 0.5f, alpha,  0.0, 0.0,  // vertex 16
        (-sqrt(3.0f) / 2.0f), -0.5f, -0.5f,                0.5f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 17
        (-sqrt(3.0f) / 2.0f), -0.5f, 0.5f,                 1.0f, 0.5f, 1.0f, alpha,  0.0, 0.0,  // vertex 18
        0.0f, -0.5f, 1.0f,                                 1.0f, 1.0f, 0.5f, alpha,  0.0, 0.0,  // vertex 19

        // extra vertices for top base texture
        (sqrt(3.0f) / 2.0f) / 1.5f, 0.5f, (0.5f / 1.5f),   1.0f, 0.5f, 1.0f, alpha,  0.0, 0.25,  // vertex 20
        (sqrt(3.0f) / 2.0f) / 1.5f, 0.5f, (-0.5f / 1.5f),  0.5f, 1.0f, 1.0f, alpha,  0.5, 0.0,   // vertex 21
        0.0f, 0.5f, (-1.0f / 1.5f),                        1.0f, 1.0f, 0.5f, alpha,  1.0, 0.25,  // vertex 22
        (-sqrt(3.0f) / 2.0f) / 1.5f, 0.5f, (-0.5f / 1.5f), 1.0f, 0.5f, 1.0f, alpha,  1.0, 0.75,  // vertex 23
        (-sqrt(3.0f) / 2.0f) / 1.5f, 0.5f, (0.5f / 1.5f),  0.5f, 1.0f, 1.0f, alpha,  0.5, 1.0,   // vertex 24
        0.0f, 0.5f, (1.0f / 1.5f),                         1.0f, 1.0f, 0.5f, alpha,  0.0, 0.75   // vertex 25
    };
    unsigned int indices[] = {
        // bottom base connections
        13, 14, 15,
        13, 15, 16,
        13, 16, 17,
        13, 17, 18,
        13, 18, 19,
        13, 19, 14,

        // top base connections
        12, 20, 21,
        12, 21, 22,
        12, 22, 23,
        12, 23, 24,
        12, 24, 25,
        12, 25, 20,

        // top to bottom face connections
        0, 6, 7, 
        0, 1, 7,
        1, 7, 8,
        1, 2, 8,
        2, 8, 9,
        2, 3, 9,
        3, 9, 10,
        3, 4, 10,
        4, 10, 11,
        4, 5, 11,
        5, 11, 6,
        5, 0, 6
    };
    unsigned int VBO, VAO, EBO;
    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    glGenBuffers(1, &EBO);

    glBindVertexArray(VAO);

    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    // prism vertex pointer
    // position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 9 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    // color attribute
    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 9 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    // texture attribute
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 9 * sizeof(float), (void*)(7 * sizeof(float)));
    glEnableVertexAttribArray(2);

    // define plate vertices and indices
    float angle = 2.0f * 3.14159f / 20.0f;
    float radius = 0.22f;
    alpha = 0.37f;

    float plateVertices[] = {
        // positions                                               // color rgba             // tex coords
        // 
        // top base (y = .5f)
        radius * sin(0 * angle), 0.5f, radius * cos(0 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 0        
        radius * sin(1 * angle), 0.5f, radius * cos(1 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.05, 0.0,  // vertex 1 
        radius * sin(2 * angle), 0.5f, radius * cos(2 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.1, 0.0,  // vertex 2  
        radius * sin(3 * angle), 0.5f, radius * cos(3 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.15, 0.0,  // vertex 3  
        radius * sin(4 * angle), 0.5f, radius * cos(4 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.2, 0.0,  // vertex 4    
        radius * sin(5 * angle), 0.5f, radius * cos(5 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.25, 0.0,  // vertex 5   
        radius * sin(6 * angle), 0.5f, radius * cos(6 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.3, 0.0,  // vertex 6   
        radius * sin(7 * angle), 0.5f, radius * cos(7 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.35, 0.0,  // vertex 7  
        radius * sin(8 * angle), 0.5f, radius * cos(8 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.4, 0.0,  // vertex 8  
        radius * sin(9 * angle), 0.5f, radius * cos(9 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.45, 0.0,  // vertex 9  
        radius * sin(10 * angle), 0.5f, radius * cos(10 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.5, 0.0,  // vertex 10   
        radius * sin(11 * angle), 0.5f, radius * cos(11 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.55, 0.0,  // vertex 11  
        radius * sin(12 * angle), 0.5f, radius * cos(12 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.6, 0.0,  // vertex 12  
        radius * sin(13 * angle), 0.5f, radius * cos(13 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.65, 0.0,  // vertex 13  
        radius * sin(14 * angle), 0.5f, radius * cos(14 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.7, 0.0,  // vertex 14   
        radius * sin(15 * angle), 0.5f, radius * cos(15 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.75, 0.0,  // vertex 15  
        radius * sin(16 * angle), 0.5f, radius * cos(16 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.8, 0.0,  // vertex 16  
        radius * sin(17 * angle), 0.5f, radius * cos(17 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.85, 0.0,  // vertex 17   
        radius * sin(18 * angle), 0.5f, radius * cos(18 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.9, 0.0,  // vertex 18  
        radius * sin(19 * angle), 0.5f, radius * cos(19 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.95, 0.0,  // vertex 19  
       
        // bottom base (y = -.5f)
        radius * sin(0 * angle), -0.5f, radius* cos(0 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 1.0,  // vertex 20        
        radius * sin(1 * angle), -0.5f, radius* cos(1 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.05, 1.0,  // vertex 21 
        radius * sin(2 * angle), -0.5f, radius* cos(2 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.1, 1.0,  // vertex 22  
        radius * sin(3 * angle), -0.5f, radius* cos(3 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.15, 1.0,  // vertex 23  
        radius * sin(4 * angle), -0.5f, radius* cos(4 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.2, 1.0,  // vertex 24    
        radius * sin(5 * angle), -0.5f, radius* cos(5 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.25, 1.0,  // vertex 25   
        radius * sin(6 * angle), -0.5f, radius* cos(6 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.3, 1.0,  // vertex 26   
        radius * sin(7 * angle), -0.5f, radius* cos(7 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.35, 1.0,  // vertex 27  
        radius * sin(8 * angle), -0.5f, radius* cos(8 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.4, 1.0,  // vertex 28  
        radius * sin(9 * angle), -0.5f, radius* cos(9 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.45, 1.0,  // vertex 29  
        radius * sin(10 * angle), -0.5f, radius* cos(10 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.5, 1.0,  // vertex 30   
        radius * sin(11 * angle), -0.5f, radius* cos(11 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.55, 1.0,  // vertex 31  
        radius * sin(12 * angle), -0.5f, radius* cos(12 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.6, 1.0,  // vertex 32  
        radius * sin(13 * angle), -0.5f, radius* cos(13 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.65, 1.0,  // vertex 33  
        radius * sin(14 * angle), -0.5f, radius* cos(14 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.7, 1.0,  // vertex 34   
        radius * sin(15 * angle), -0.5f, radius* cos(15 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.75, 1.0,  // vertex 35  
        radius * sin(16 * angle), -0.5f, radius* cos(16 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.8, 1.0,  // vertex 36  
        radius * sin(17 * angle), -0.5f, radius* cos(17 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.85, 1.0,  // vertex 37   
        radius * sin(18 * angle), -0.5f, radius* cos(18 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.9, 1.0,  // vertex 38  
        radius * sin(19 * angle), -0.5f, radius* cos(19 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.95, 1.0,  // vertex 39  
        
        // top vertex
        0.0f, 0.5f, 0.0f,                                          1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 40

        // bottom vertex
        0.0f, -0.5f, 0.0f,                                         1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 41

        // extra vertex for wrapping
        radius * sin(0 * angle), 0.5f, radius* cos(0 * angle),    1.0f, 1.0f, 1.0f, alpha,  1.0, 0.0,   // vertex 42 
        radius * sin(0 * angle), -0.5f, radius* cos(0 * angle),    1.0f, 1.0f, 1.0f, alpha,  1.0, 1.0   // vertex 43
    };
    unsigned int plateIndices[] = {
        // bottom base connections
        41, 20, 21,
        41, 21, 22,
        41, 22, 23,
        41, 23, 24,
        41, 24, 25,
        41, 25, 26,
        41, 26, 27,
        41, 27, 28,
        41, 28, 29,
        41, 29, 30,
        41, 30, 31,
        41, 31, 32,
        41, 32, 33,
        41, 33, 34,
        41, 34, 35,
        41, 35, 36,
        41, 36, 37,
        41, 37, 38,
        41, 38, 39,
        41, 39, 43,

        // top base connections
        40, 0, 1,
        40, 1, 2,
        40, 2, 3,
        40, 3, 4,
        40, 4, 5,
        40, 5, 6,
        40, 6, 7,
        40, 7, 8,
        40, 8, 9,
        40, 9, 10,
        40, 10, 11,
        40, 11, 12,
        40, 12, 13,
        40, 13, 14,
        40, 14, 15,
        40, 15, 16,
        40, 16, 17,
        40, 17, 18,
        40, 18, 19,
        40, 19, 42,

        // top to bottom face connections
        0, 20, 21,
        0, 1,  21,
        1, 21, 22,
        1, 2, 22,
        2, 22, 23,
        2, 3, 23,
        3, 23, 24,
        3, 4, 24,
        4, 24, 25,
        4, 5, 25,
        5, 25, 26,
        5, 6, 26,
        6, 26, 27,
        6, 7, 27,
        7, 27, 28,
        7, 8, 28,
        8, 28, 29,
        8, 9, 29,
        9, 29, 30,
        9, 10, 30,
        10, 30, 31,
        10, 11, 31,
        11, 31, 32,
        11, 12, 32,
        12, 32, 33,
        12, 13, 33,
        13, 33, 34,
        13, 14, 34,
        14, 34, 35,
        14, 15, 35,
        15, 35, 36,
        15, 16, 36,
        16, 36, 37,
        16, 17, 37,
        17, 37, 38,
        17, 18, 38,
        18, 38, 39,
        18, 19, 39,
        19, 39, 43,
        19, 42, 43
    };
    unsigned int plateVBO, plateVAO, plateEBO;
    glGenVertexArrays(1, &plateVAO);
    glGenBuffers(1, &plateVBO);
    glGenBuffers(1, &plateEBO);

    glBindVertexArray(plateVAO);

    glBindBuffer(GL_ARRAY_BUFFER, plateVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(plateVertices), plateVertices, GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, plateEBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(plateIndices), plateIndices, GL_STATIC_DRAW);

    // plate vertex pointer
    // position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 9 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    // color attribute
    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 9 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    // texture attribute
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 9 * sizeof(float), (void*)(7 * sizeof(float)));
    glEnableVertexAttribArray(2);

    // define cylindrical prism vertices and indices
    radius = 0.22f;
    alpha = 1.0f;

    float cylinderVertices[] = {
        // positions                                               // color rgba             // tex coords
        // 
        // top base (y = .5f)
        radius * sin(0 * angle), 0.5f, radius * cos(0 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 0        
        radius * sin(1 * angle), 0.5f, radius * cos(1 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.05, 0.0,  // vertex 1 
        radius * sin(2 * angle), 0.5f, radius * cos(2 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.1, 0.0,   // vertex 2  
        radius * sin(3 * angle), 0.5f, radius * cos(3 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.15, 0.0,  // vertex 3  
        radius * sin(4 * angle), 0.5f, radius * cos(4 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.2, 0.0,   // vertex 4    
        radius * sin(5 * angle), 0.5f, radius * cos(5 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.25, 0.0,  // vertex 5   
        radius * sin(6 * angle), 0.5f, radius * cos(6 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.3, 0.0,   // vertex 6   
        radius * sin(7 * angle), 0.5f, radius * cos(7 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.35, 0.0,  // vertex 7  
        radius * sin(8 * angle), 0.5f, radius * cos(8 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.4, 0.0,   // vertex 8  
        radius * sin(9 * angle), 0.5f, radius * cos(9 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.45, 0.0,  // vertex 9  
        radius * sin(10 * angle), 0.5f, radius * cos(10 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.5, 0.0,   // vertex 10   
        radius * sin(11 * angle), 0.5f, radius * cos(11 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.55, 0.0,  // vertex 11  
        radius * sin(12 * angle), 0.5f, radius * cos(12 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.6, 0.0,   // vertex 12  
        radius * sin(13 * angle), 0.5f, radius * cos(13 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.65, 0.0,  // vertex 13  
        radius * sin(14 * angle), 0.5f, radius * cos(14 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.7, 0.0,   // vertex 14   
        radius * sin(15 * angle), 0.5f, radius * cos(15 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.75, 0.0,  // vertex 15  
        radius * sin(16 * angle), 0.5f, radius * cos(16 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.8, 0.0,   // vertex 16  
        radius * sin(17 * angle), 0.5f, radius * cos(17 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.85, 0.0,  // vertex 17   
        radius * sin(18 * angle), 0.5f, radius * cos(18 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.9, 0.0,   // vertex 18  
        radius * sin(19 * angle), 0.5f, radius * cos(19 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.95, 0.0,  // vertex 19  

        // bottom base (y = -.5f)
        radius * sin(0 * angle), -0.5f, radius * cos(0 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 1.0,   // vertex 20        
        radius * sin(1 * angle), -0.5f, radius * cos(1 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.05, 1.0,  // vertex 21 
        radius * sin(2 * angle), -0.5f, radius * cos(2 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.1, 1.0,   // vertex 22  
        radius * sin(3 * angle), -0.5f, radius * cos(3 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.15, 1.0,  // vertex 23  
        radius * sin(4 * angle), -0.5f, radius * cos(4 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.2, 1.0,   // vertex 24    
        radius * sin(5 * angle), -0.5f, radius * cos(5 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.25, 1.0,  // vertex 25   
        radius * sin(6 * angle), -0.5f, radius * cos(6 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.3, 1.0,   // vertex 26   
        radius * sin(7 * angle), -0.5f, radius * cos(7 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.35, 1.0,  // vertex 27  
        radius * sin(8 * angle), -0.5f, radius * cos(8 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.4, 1.0,   // vertex 28  
        radius * sin(9 * angle), -0.5f, radius * cos(9 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.45, 1.0,  // vertex 29  
        radius * sin(10 * angle), -0.5f, radius * cos(10 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.5, 1.0,   // vertex 30   
        radius * sin(11 * angle), -0.5f, radius * cos(11 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.55, 1.0,  // vertex 31  
        radius * sin(12 * angle), -0.5f, radius * cos(12 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.6, 1.0,   // vertex 32  
        radius * sin(13 * angle), -0.5f, radius * cos(13 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.65, 1.0,  // vertex 33  
        radius * sin(14 * angle), -0.5f, radius * cos(14 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.7, 1.0,   // vertex 34   
        radius * sin(15 * angle), -0.5f, radius * cos(15 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.75, 1.0,  // vertex 35  
        radius * sin(16 * angle), -0.5f, radius * cos(16 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.8, 1.0,   // vertex 36  
        radius * sin(17 * angle), -0.5f, radius * cos(17 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.85, 1.0,  // vertex 37   
        radius * sin(18 * angle), -0.5f, radius * cos(18 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.9, 1.0,   // vertex 38  
        radius * sin(19 * angle), -0.5f, radius * cos(19 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.95, 1.0,  // vertex 39  

        // top vertex
        0.0f, 0.5f, 0.0f,                                          1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 40

        // bottom vertex
        0.0f, -0.5f, 0.0f,                                         1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 41

        // extra vertices for wrapping
        radius * sin(0 * angle), 0.5f, radius* cos(0 * angle),    1.0f, 1.0f, 1.0f, alpha,  1.0, 0.0,   // vertex 42 
        radius * sin(0 * angle), -0.5f, radius* cos(0 * angle),    1.0f, 1.0f, 1.0f, alpha,  1.0, 1.0,  // vertex 43

        // extra top vertices for lid
        radius* sin(0 * angle), 0.5f, radius* cos(0 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.5,  // vertex 44        
        radius* sin(1 * angle), 0.5f, radius* cos(1 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.1, 0.4,  // vertex 45
        radius* sin(2 * angle), 0.5f, radius* cos(2 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.2, 0.3,  // vertex 46 
        radius* sin(3 * angle), 0.5f, radius* cos(3 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.3, 0.2,  // vertex 47 
        radius* sin(4 * angle), 0.5f, radius* cos(4 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.4, 0.1,  // vertex 48   
        radius* sin(5 * angle), 0.5f, radius* cos(5 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.5, 0.0,  // vertex 49  
        radius* sin(6 * angle), 0.5f, radius* cos(6 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.6, 0.1,  // vertex 50   
        radius* sin(7 * angle), 0.5f, radius* cos(7 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.7, 0.2,  // vertex 51
        radius* sin(8 * angle), 0.5f, radius* cos(8 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.8, 0.3,  // vertex 52 
        radius* sin(9 * angle), 0.5f, radius* cos(9 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.9, 0.4,  // vertex 53 
        radius* sin(10 * angle), 0.5f, radius* cos(10 * angle),  1.0f, 1.0f, 1.0f, alpha,  1.0, 0.5,  // vertex 54  
        radius* sin(11 * angle), 0.5f, radius* cos(11 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.9, 0.6,  // vertex 55 
        radius* sin(12 * angle), 0.5f, radius* cos(12 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.8, 0.7,  // vertex 56
        radius* sin(13 * angle), 0.5f, radius* cos(13 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.7, 0.8,  // vertex 57 
        radius* sin(14 * angle), 0.5f, radius* cos(14 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.6, 0.9,  // vertex 58 
        radius* sin(15 * angle), 0.5f, radius* cos(15 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.5, 1.0,  // vertex 59 
        radius* sin(16 * angle), 0.5f, radius* cos(16 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.4, 0.9,  // vertex 60  
        radius* sin(17 * angle), 0.5f, radius* cos(17 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.3, 0.8,  // vertex 61   
        radius* sin(18 * angle), 0.5f, radius* cos(18 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.2, 0.7,  // vertex 62  
        radius* sin(19 * angle), 0.5f, radius* cos(19 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.1, 0.6   // vertex 63
    };
    unsigned int cylinderIndices[] = {
        // top base connections
        40, 44, 45,
        40, 45, 46,
        40, 46, 47,
        40, 47, 48,
        40, 48, 49,
        40, 49, 50,
        40, 50, 51,
        40, 51, 52,
        40, 52, 53,
        40, 53, 54,
        40, 54, 55,
        40, 55, 56,
        40, 56, 57,
        40, 57, 58,
        40, 58, 59,
        40, 59, 60,
        40, 60, 61,
        40, 61, 62,
        40, 62, 63,
        40, 63, 44,

        // bottom base connections
        41, 20, 21,
        41, 21, 22,
        41, 22, 23,
        41, 23, 24,
        41, 24, 25,
        41, 25, 26,
        41, 26, 27,
        41, 27, 28,
        41, 28, 29,
        41, 29, 30,
        41, 30, 31,
        41, 31, 32,
        41, 32, 33,
        41, 33, 34,
        41, 34, 35,
        41, 35, 36,
        41, 36, 37,
        41, 37, 38,
        41, 38, 39,
        41, 39, 20,

        // top to bottom face connections
        0, 20, 21,
        0, 1,  21,
        1, 21, 22,
        1, 2, 22,
        2, 22, 23,
        2, 3, 23,
        3, 23, 24,
        3, 4, 24,
        4, 24, 25,
        4, 5, 25,
        5, 25, 26,
        5, 6, 26,
        6, 26, 27,
        6, 7, 27,
        7, 27, 28,
        7, 8, 28,
        8, 28, 29,
        8, 9, 29,
        9, 29, 30,
        9, 10, 30,
        10, 30, 31,
        10, 11, 31,
        11, 31, 32,
        11, 12, 32,
        12, 32, 33,
        12, 13, 33,
        13, 33, 34,
        13, 14, 34,
        14, 34, 35,
        14, 15, 35,
        15, 35, 36,
        15, 16, 36,
        16, 36, 37,
        16, 17, 37,
        17, 37, 38,
        17, 18, 38,
        18, 38, 39,
        18, 19, 39,
        19, 39, 43,
        19, 42, 43
    };
    unsigned int cylinderVBO, cylinderVAO, cylinderEBO;
    glGenVertexArrays(1, &cylinderVAO);
    glGenBuffers(1, &cylinderVBO);
    glGenBuffers(1, &cylinderEBO);

    glBindVertexArray(cylinderVAO);

    glBindBuffer(GL_ARRAY_BUFFER, cylinderVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(cylinderVertices), cylinderVertices, GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, cylinderEBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(cylinderIndices), cylinderIndices, GL_STATIC_DRAW);

    // cylinder vertex pointer
    // position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 9 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    // color attribute
    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 9 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    // texture attribute
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 9 * sizeof(float), (void*)(7 * sizeof(float)));
    glEnableVertexAttribArray(2);

    // define spherical prism vertices and indices
    float midRadius = 0.44f;
    float quartRadius = 0.5f;
    radius = 0.22f;
    alpha = 1.0f;

    float sphereVertices[] = {
        // positions                                               // color rgba             // tex coords
        // 
        // top base (y = 0.5f)
        radius * sin(0 * angle), 0.5f, radius * cos(0 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 0        
        radius * sin(1 * angle), 0.5f, radius * cos(1 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.05, 0.0,  // vertex 1 
        radius * sin(2 * angle), 0.5f, radius * cos(2 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.1, 0.0,   // vertex 2  
        radius * sin(3 * angle), 0.5f, radius * cos(3 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.15, 0.0,  // vertex 3  
        radius * sin(4 * angle), 0.5f, radius * cos(4 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.2, 0.0,   // vertex 4    
        radius * sin(5 * angle), 0.5f, radius * cos(5 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.25, 0.0,  // vertex 5   
        radius * sin(6 * angle), 0.5f, radius * cos(6 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.3, 0.0,   // vertex 6   
        radius * sin(7 * angle), 0.5f, radius * cos(7 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.35, 0.0,  // vertex 7  
        radius * sin(8 * angle), 0.5f, radius * cos(8 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.4, 0.0,   // vertex 8  
        radius * sin(9 * angle), 0.5f, radius * cos(9 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.45, 0.0,  // vertex 9  
        radius * sin(10 * angle), 0.5f, radius * cos(10 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.5, 0.0,   // vertex 10   
        radius * sin(11 * angle), 0.5f, radius * cos(11 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.55, 0.0,  // vertex 11  
        radius * sin(12 * angle), 0.5f, radius * cos(12 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.6, 0.0,   // vertex 12  
        radius * sin(13 * angle), 0.5f, radius * cos(13 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.65, 0.0,  // vertex 13  
        radius * sin(14 * angle), 0.5f, radius * cos(14 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.7, 0.0,   // vertex 14   
        radius * sin(15 * angle), 0.5f, radius * cos(15 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.75, 0.0,  // vertex 15  
        radius * sin(16 * angle), 0.5f, radius * cos(16 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.8, 0.0,   // vertex 16  
        radius * sin(17 * angle), 0.5f, radius * cos(17 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.85, 0.0,  // vertex 17   
        radius * sin(18 * angle), 0.5f, radius * cos(18 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.9, 0.0,   // vertex 18  
        radius * sin(19 * angle), 0.5f, radius * cos(19 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.95, 0.0,  // vertex 19  

        // bottom base (y = -0.5f)
        radius * sin(0 * angle), -0.5f, radius * cos(0 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 1.0,   // vertex 20        
        radius * sin(1 * angle), -0.5f, radius * cos(1 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.05, 1.0,  // vertex 21 
        radius * sin(2 * angle), -0.5f, radius * cos(2 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.1, 1.0,   // vertex 22  
        radius * sin(3 * angle), -0.5f, radius * cos(3 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.15, 1.0,  // vertex 23  
        radius * sin(4 * angle), -0.5f, radius * cos(4 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.2, 1.0,   // vertex 24    
        radius * sin(5 * angle), -0.5f, radius * cos(5 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.25, 1.0,  // vertex 25   
        radius * sin(6 * angle), -0.5f, radius * cos(6 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.3, 1.0,   // vertex 26   
        radius * sin(7 * angle), -0.5f, radius * cos(7 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.35, 1.0,  // vertex 27  
        radius * sin(8 * angle), -0.5f, radius * cos(8 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.4, 1.0,   // vertex 28  
        radius * sin(9 * angle), -0.5f, radius * cos(9 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.45, 1.0,  // vertex 29  
        radius * sin(10 * angle), -0.5f, radius * cos(10 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.5, 1.0,   // vertex 30   
        radius * sin(11 * angle), -0.5f, radius * cos(11 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.55, 1.0,  // vertex 31  
        radius * sin(12 * angle), -0.5f, radius * cos(12 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.6, 1.0,   // vertex 32  
        radius * sin(13 * angle), -0.5f, radius * cos(13 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.65, 1.0,  // vertex 33  
        radius * sin(14 * angle), -0.5f, radius * cos(14 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.7, 1.0,   // vertex 34   
        radius * sin(15 * angle), -0.5f, radius * cos(15 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.75, 1.0,  // vertex 35  
        radius * sin(16 * angle), -0.5f, radius * cos(16 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.8, 1.0,   // vertex 36  
        radius * sin(17 * angle), -0.5f, radius * cos(17 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.85, 1.0,  // vertex 37   
        radius * sin(18 * angle), -0.5f, radius * cos(18 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.9, 1.0,   // vertex 38  
        radius * sin(19 * angle), -0.5f, radius * cos(19 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.95, 1.0,  // vertex 39  

        // top vertex
        0.0f, 0.5f, 0.0f,                                          1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 40

        // bottom vertex
        0.0f, -0.5f, 0.0f,                                         1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 41

        // extra vertices for wrapping
        radius * sin(0 * angle), 0.5f, radius * cos(0 * angle),    1.0f, 1.0f, 1.0f, alpha,  1.0, 0.0,   // vertex 42 
        radius * sin(0 * angle), -0.5f, radius * cos(0 * angle),    1.0f, 1.0f, 1.0f, alpha,  1.0, 1.0,  // vertex 43

        // extra top vertices for top base
        radius * sin(0 * angle), 0.5f, radius * cos(0 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 44        
        radius * sin(1 * angle), 0.5f, radius * cos(1 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 45
        radius * sin(2 * angle), 0.5f, radius * cos(2 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 46 
        radius * sin(3 * angle), 0.5f, radius * cos(3 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 47 
        radius * sin(4 * angle), 0.5f, radius * cos(4 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 48   
        radius * sin(5 * angle), 0.5f, radius * cos(5 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 49  
        radius * sin(6 * angle), 0.5f, radius * cos(6 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 50   
        radius * sin(7 * angle), 0.5f, radius * cos(7 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 51
        radius * sin(8 * angle), 0.5f, radius * cos(8 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 52 
        radius * sin(9 * angle), 0.5f, radius * cos(9 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 53 
        radius * sin(10 * angle), 0.5f, radius * cos(10 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 54  
        radius * sin(11 * angle), 0.5f, radius * cos(11 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 55 
        radius * sin(12 * angle), 0.5f, radius * cos(12 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 56
        radius * sin(13 * angle), 0.5f, radius * cos(13 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 57 
        radius * sin(14 * angle), 0.5f, radius * cos(14 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 58 
        radius * sin(15 * angle), 0.5f, radius * cos(15 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 59 
        radius * sin(16 * angle), 0.5f, radius * cos(16 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 60  
        radius * sin(17 * angle), 0.5f, radius * cos(17 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 61   
        radius * sin(18 * angle), 0.5f, radius * cos(18 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 62  
        radius * sin(19 * angle), 0.5f, radius * cos(19 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 63

        // top middle circle (y = 0.35f)
        midRadius* sin(0 * angle), 0.35f, midRadius* cos(0 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.20,   // vertex 64       
        midRadius* sin(1 * angle), 0.35f, midRadius* cos(1 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.05, 0.20,  // vertex 65
        midRadius* sin(2 * angle), 0.35f, midRadius* cos(2 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.1, 0.20,   // vertex 66  
        midRadius* sin(3 * angle), 0.35f, midRadius* cos(3 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.15, 0.20,  // vertex 67  
        midRadius* sin(4 * angle), 0.35f, midRadius* cos(4 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.2, 0.20,   // vertex 68    
        midRadius* sin(5 * angle), 0.35f, midRadius* cos(5 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.25, 0.20,  // vertex 69   
        midRadius* sin(6 * angle), 0.35f, midRadius* cos(6 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.3, 0.20,   // vertex 70   
        midRadius* sin(7 * angle), 0.35f, midRadius* cos(7 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.35, 0.20,  // vertex 71  
        midRadius* sin(8 * angle), 0.35f, midRadius* cos(8 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.4, 0.20,   // vertex 72  
        midRadius* sin(9 * angle), 0.35f, midRadius* cos(9 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.45, 0.20,  // vertex 73  
        midRadius* sin(10 * angle), 0.35f, midRadius* cos(10 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.5, 0.20,   // vertex 74   
        midRadius* sin(11 * angle), 0.35f, midRadius* cos(11 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.55, 0.20,  // vertex 75  
        midRadius* sin(12 * angle), 0.35f, midRadius* cos(12 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.6, 0.20,   // vertex 76  
        midRadius* sin(13 * angle), 0.35f, midRadius* cos(13 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.65, 0.20,  // vertex 77  
        midRadius* sin(14 * angle), 0.35f, midRadius* cos(14 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.7, 0.20,   // vertex 78   
        midRadius* sin(15 * angle), 0.35f, midRadius* cos(15 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.75, 0.20,  // vertex 79  
        midRadius* sin(16 * angle), 0.35f, midRadius* cos(16 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.8, 0.20,   // vertex 80  
        midRadius* sin(17 * angle), 0.35f, midRadius* cos(17 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.85, 0.20,  // vertex 81   
        midRadius* sin(18 * angle), 0.35f, midRadius* cos(18 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.9, 0.20,   // vertex 82  
        midRadius* sin(19 * angle), 0.35f, midRadius* cos(19 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.95, 0.20,  // vertex 83  

        // bottom middle circle (y = -0.35f)
        midRadius* sin(0 * angle), -0.35f, midRadius* cos(0 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.80,   // vertex 84        
        midRadius* sin(1 * angle), -0.35f, midRadius* cos(1 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.05, 0.80,  // vertex 85 
        midRadius* sin(2 * angle), -0.35f, midRadius* cos(2 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.1, 0.80,   // vertex 86  
        midRadius* sin(3 * angle), -0.35f, midRadius* cos(3 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.15, 0.80,  // vertex 87  
        midRadius* sin(4 * angle), -0.35f, midRadius* cos(4 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.2, 0.80,   // vertex 88    
        midRadius* sin(5 * angle), -0.35f, midRadius* cos(5 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.25, 0.80,  // vertex 89   
        midRadius* sin(6 * angle), -0.35f, midRadius* cos(6 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.3, 0.80,   // vertex 90   
        midRadius* sin(7 * angle), -0.35f, midRadius* cos(7 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.35, 0.80,  // vertex 91  
        midRadius* sin(8 * angle), -0.35f, midRadius* cos(8 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.4, 0.80,   // vertex 92  
        midRadius* sin(9 * angle), -0.35f, midRadius* cos(9 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.45, 0.80,  // vertex 93  
        midRadius* sin(10 * angle), -0.35f, midRadius* cos(10 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.5, 0.80,   // vertex 94   
        midRadius* sin(11 * angle), -0.35f, midRadius* cos(11 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.55, 0.80,  // vertex 95  
        midRadius* sin(12 * angle), -0.35f, midRadius* cos(12 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.6, 0.80,   // vertex 96  
        midRadius* sin(13 * angle), -0.35f, midRadius* cos(13 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.65, 0.80,  // vertex 97  
        midRadius* sin(14 * angle), -0.35f, midRadius* cos(14 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.7, 0.80,   // vertex 98   
        midRadius* sin(15 * angle), -0.35f, midRadius* cos(15 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.75, 0.80,  // vertex 99  
        midRadius* sin(16 * angle), -0.35f, midRadius* cos(16 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.8, 0.80,   // vertex 100  
        midRadius* sin(17 * angle), -0.35f, midRadius* cos(17 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.85, 0.80,  // vertex 101  
        midRadius* sin(18 * angle), -0.35f, midRadius* cos(18 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.9, 0.80,   // vertex 102 
        midRadius* sin(19 * angle), -0.35f, midRadius* cos(19 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.95, 0.80,   // vertex 103 

        // top quarter circle (y = 0.15f)
        quartRadius* sin(0 * angle), 0.15f, quartRadius* cos(0 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.40,   // vertex 104       
        quartRadius* sin(1 * angle), 0.15f, quartRadius* cos(1 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.05, 0.40,  // vertex 105
        quartRadius* sin(2 * angle), 0.15f, quartRadius* cos(2 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.1, 0.40,   // vertex 106  
        quartRadius* sin(3 * angle), 0.15f, quartRadius* cos(3 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.15, 0.40,  // vertex 107  
        quartRadius* sin(4 * angle), 0.15f, quartRadius* cos(4 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.2, 0.40,   // vertex 108    
        quartRadius* sin(5 * angle), 0.15f, quartRadius* cos(5 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.25, 0.40,  // vertex 109   
        quartRadius* sin(6 * angle), 0.15f, quartRadius* cos(6 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.3, 0.40,   // vertex 110   
        quartRadius* sin(7 * angle), 0.15f, quartRadius* cos(7 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.35, 0.40,  // vertex 111  
        quartRadius* sin(8 * angle), 0.15f, quartRadius* cos(8 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.4, 0.40,   // vertex 112  
        quartRadius* sin(9 * angle), 0.15f, quartRadius* cos(9 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.45, 0.40,  // vertex 113  
        quartRadius* sin(10 * angle), 0.15f, quartRadius* cos(10 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.5, 0.40,   // vertex 114   
        quartRadius* sin(11 * angle), 0.15f, quartRadius* cos(11 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.55, 0.40,  // vertex 115  
        quartRadius* sin(12 * angle), 0.15f, quartRadius* cos(12 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.6, 0.40,   // vertex 116  
        quartRadius* sin(13 * angle), 0.15f, quartRadius* cos(13 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.65, 0.40,  // vertex 117  
        quartRadius* sin(14 * angle), 0.15f, quartRadius* cos(14 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.7, 0.40,   // vertex 118   
        quartRadius* sin(15 * angle), 0.15f, quartRadius* cos(15 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.75, 0.40,  // vertex 119  
        quartRadius* sin(16 * angle), 0.15f, quartRadius* cos(16 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.8, 0.40,   // vertex 120  
        quartRadius* sin(17 * angle), 0.15f, quartRadius* cos(17 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.85, 0.40,  // vertex 121   
        quartRadius* sin(18 * angle), 0.15f, quartRadius* cos(18 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.9, 0.40,   // vertex 122  
        quartRadius* sin(19 * angle), 0.15f, quartRadius* cos(19 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.95, 0.40,  // vertex 123  

        // bottom quarter circle (y = -0.15f)
        quartRadius* sin(0 * angle), -0.15f, quartRadius* cos(0 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.60,   // vertex 124        
        quartRadius* sin(1 * angle), -0.15f, quartRadius* cos(1 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.05, 0.60,  // vertex 125 
        quartRadius* sin(2 * angle), -0.15f, quartRadius* cos(2 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.1, 0.60,   // vertex 126  
        quartRadius* sin(3 * angle), -0.15f, quartRadius* cos(3 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.15, 0.60,  // vertex 127  
        quartRadius* sin(4 * angle), -0.15f, quartRadius* cos(4 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.2, 0.60,   // vertex 128    
        quartRadius* sin(5 * angle), -0.15f, quartRadius* cos(5 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.25, 0.60,  // vertex 129   
        quartRadius* sin(6 * angle), -0.15f, quartRadius* cos(6 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.3, 0.60,   // vertex 130   
        quartRadius* sin(7 * angle), -0.15f, quartRadius* cos(7 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.35, 0.60,  // vertex 131  
        quartRadius* sin(8 * angle), -0.15f, quartRadius* cos(8 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.4, 0.60,   // vertex 132  
        quartRadius* sin(9 * angle), -0.15f, quartRadius* cos(9 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.45, 0.60,  // vertex 133  
        quartRadius* sin(10 * angle), -0.15f, quartRadius* cos(10 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.5, 0.60,   // vertex 134   
        quartRadius* sin(11 * angle), -0.15f, quartRadius* cos(11 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.55, 0.60,  // vertex 135  
        quartRadius* sin(12 * angle), -0.15f, quartRadius* cos(12 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.6, 0.60,   // vertex 136  
        quartRadius* sin(13 * angle), -0.15f, quartRadius* cos(13 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.65, 0.60,  // vertex 137  
        quartRadius* sin(14 * angle), -0.15f, quartRadius* cos(14 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.7, 0.60,   // vertex 138   
        quartRadius* sin(15 * angle), -0.15f, quartRadius* cos(15 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.75, 0.60,  // vertex 139  
        quartRadius* sin(16 * angle), -0.15f, quartRadius* cos(16 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.8, 0.60,   // vertex 140  
        quartRadius* sin(17 * angle), -0.15f, quartRadius* cos(17 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.85, 0.60,  // vertex 141  
        quartRadius* sin(18 * angle), -0.15f, quartRadius* cos(18 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.9, 0.60,   // vertex 142 
        quartRadius* sin(19 * angle), -0.15f, quartRadius* cos(19 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.95, 0.60,   // vertex 143 

        // extra vertices for wrapping
        midRadius* sin(0 * angle), 0.35f, midRadius* cos(0 * angle), 1.0f, 1.0f, 1.0f, alpha, 1.0, 0.2,   // vertex 144 
        midRadius* sin(0 * angle), -0.35f, midRadius* cos(0 * angle), 1.0f, 1.0f, 1.0f, alpha, 1.0, 0.8,  // vertex 145
           
        quartRadius* sin(0 * angle), 0.15f, quartRadius* cos(0 * angle), 1.0f, 1.0f, 1.0f, alpha, 1.0, 0.4,   // vertex 146
        quartRadius* sin(0 * angle), -0.15f, quartRadius* cos(0 * angle), 1.0f, 1.0f, 1.0f, alpha, 1.0, 0.6   // vertex 147

    };
    unsigned int sphereIndices[] = {
        // top base connections
        40, 44, 45,
        40, 45, 46,
        40, 46, 47,
        40, 47, 48,
        40, 48, 49,
        40, 49, 50,
        40, 50, 51,
        40, 51, 52,
        40, 52, 53,
        40, 53, 54,
        40, 54, 55,
        40, 55, 56,
        40, 56, 57,
        40, 57, 58,
        40, 58, 59,
        40, 59, 60,
        40, 60, 61,
        40, 61, 62,
        40, 62, 63,
        40, 63, 44,

        // bottom base connections
        41, 20, 21,
        41, 21, 22,
        41, 22, 23,
        41, 23, 24,
        41, 24, 25,
        41, 25, 26,
        41, 26, 27,
        41, 27, 28,
        41, 28, 29,
        41, 29, 30,
        41, 30, 31,
        41, 31, 32,
        41, 32, 33,
        41, 33, 34,
        41, 34, 35,
        41, 35, 36,
        41, 36, 37,
        41, 37, 38,
        41, 38, 39,
        41, 39, 20,

        // top to top middle face connections
        0, 64, 65,
        0, 1,  65,
        1, 65, 66,
        1, 2, 66,
        2, 66, 67,
        2, 3, 67,
        3, 67, 68,
        3, 4, 68,
        4, 68, 69,
        4, 5, 69,
        5, 69, 70,
        5, 6, 70,
        6, 70, 71,
        6, 7, 71,
        7, 71, 72,
        7, 8, 72,
        8, 72, 73,
        8, 9, 73,
        9, 73, 74,
        9, 10, 74,
        10, 74, 75,
        10, 11, 75,
        11, 75, 76,
        11, 12, 76,
        12, 76, 77,
        12, 13, 77,
        13, 77, 78,
        13, 14, 78,
        14, 78, 79,
        14, 15, 79,
        15, 79, 80,
        15, 16, 80,
        16, 80, 81,
        16, 17, 81,
        17, 81, 82,
        17, 18, 82,
        18, 82, 83,
        18, 19, 83,
        19, 83, 144,
        19, 42, 144,

        // top quarter to top middle face connections
        104, 64, 65,
        104, 105,  65,
        105, 65, 66,
        105, 106, 66,
        106, 66, 67,
        106, 107, 67,
        107, 67, 68,
        107, 108, 68,
        108, 68, 69,
        108, 109, 69,
        109, 69, 70,
        109, 110, 70,
        110, 70, 71,
        110, 111, 71,
        111, 71, 72,
        111, 112, 72,
        112, 72, 73,
        112, 113, 73,
        113, 73, 74,
        113, 114, 74,
        114, 74, 75,
        114, 115, 75,
        115, 75, 76,
        115, 116, 76,
        116, 76, 77,
        116, 117, 77,
        117, 77, 78,
        117, 118, 78,
        118, 78, 79,
        118, 119, 79,
        119, 79, 80,
        119, 120, 80,
        120, 80, 81,
        120, 121, 81,
        121, 81, 82,
        121, 122, 82,
        122, 82, 83,
        122, 123, 83,
        123, 83, 144,
        123, 146, 144,

        // top quarter to bottom quarter face connections
        104, 124, 125,
        104, 105, 125,
        105, 125, 126,
        105, 106, 126,
        106, 126, 127,
        106, 107, 127,
        107, 127, 128,
        107, 108, 128,
        108, 128, 129,
        108, 109, 129,
        109, 129, 130,
        109, 110, 130,
        110, 130, 131,
        110, 111, 131,
        111, 131, 132,
        111, 112, 132,
        112, 132, 133,
        112, 113, 133,
        113, 133, 134,
        113, 114, 134,
        114, 134, 135,
        114, 115, 135,
        115, 135, 136,
        115, 116, 136,
        116, 136, 137,
        116, 117, 137,
        117, 137, 138,
        117, 118, 138,
        118, 138, 139,
        118, 119, 139,
        119, 139, 140,
        119, 120, 140,
        120, 140, 141,
        120, 121, 141,
        121, 141, 142,
        121, 122, 142,
        122, 142, 143,
        122, 123, 143,
        123, 143, 147,
        123, 146, 147,

        // bottom quarter to bottom middle face connections
        124, 84, 85,
        124, 125, 85,
        125, 85, 86,
        125, 126, 86,
        126, 86, 87,
        126, 127, 87,
        127, 87, 88,
        127, 128, 88,
        128, 88, 89,
        128, 129, 89,
        129, 89, 90,
        129, 130, 90,
        130, 90, 91,
        130, 131, 91,
        131, 91, 92,
        131, 132, 92,
        132, 92, 93,
        132, 133, 93,
        133, 93, 94,
        133, 134, 94,
        134, 94, 95,
        134, 135, 95,
        135, 95, 96,
        135, 136, 96,
        136, 96, 97,
        136, 137, 97,
        137, 97, 98,
        137, 138, 98,
        138, 98, 99,
        138, 139, 99,
        139, 99, 100,
        139, 140, 100,
        140, 100, 101,
        140, 141, 101,
        141, 101, 102,
        141, 142, 102,
        142, 102, 103,
        142, 143, 103,
        143, 103, 145,
        143, 147, 145,
    
        // bottom to bottom middle face connections
        20, 84, 85,
        20, 21, 85,
        21, 85, 86,
        21, 22, 86,
        22, 86, 87,
        22, 23, 87,
        23, 87, 88,
        23, 24, 88,
        24, 88, 89,
        24, 25, 89,
        25, 89, 90,
        25, 26, 90,
        26, 90, 91,
        26, 27, 91,
        27, 91, 92,
        27, 28, 92,
        28, 92, 93,
        28, 29, 93,
        29, 93, 94,
        29, 30, 94,
        30, 94, 95,
        30, 31, 95,
        31, 95, 96,
        31, 32, 96,
        32, 96, 97,
        32, 33, 97,
        33, 97, 98,
        33, 34, 98,
        34, 98, 99,
        34, 35, 99,
        35, 99, 100,
        35, 36, 100,
        36, 100, 101,
        36, 37, 101,
        37, 101, 102,
        37, 38, 102,
        38, 102, 103,
        38, 39, 103,
        39, 103, 145,
        39, 43, 145
    };
    unsigned int sphereVBO, sphereVAO, sphereEBO;
    glGenVertexArrays(1, &sphereVAO);
    glGenBuffers(1, &sphereVBO);
    glGenBuffers(1, &sphereEBO);

    glBindVertexArray(sphereVAO);

    glBindBuffer(GL_ARRAY_BUFFER, sphereVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(sphereVertices), sphereVertices, GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, sphereEBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(sphereIndices), sphereIndices, GL_STATIC_DRAW);

    // sphere vertex pointer
    // position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 9 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    // color attribute
    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 9 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    // texture attribute
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 9 * sizeof(float), (void*)(7 * sizeof(float)));
    glEnableVertexAttribArray(2);

    // define torus prism vertices and indices
    midRadius = 0.44f;
    quartRadius = 0.5f;
    radius = 0.22f;
    alpha = 1.0f;

    float torusVertices[] = {
        // positions                                               // color rgba             // tex coords
        // 
        // top ring (y = 0.5f)
        midRadius* sin(0 * angle), 0.5f, midRadius* cos(0 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 0        
        midRadius* sin(1 * angle), 0.5f, midRadius* cos(1 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 1 
        midRadius* sin(2 * angle), 0.5f, midRadius* cos(2 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 2  
        midRadius* sin(3 * angle), 0.5f, midRadius* cos(3 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 3  
        midRadius* sin(4 * angle), 0.5f, midRadius* cos(4 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 4    
        midRadius* sin(5 * angle), 0.5f, midRadius* cos(5 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 5   
        midRadius* sin(6 * angle), 0.5f, midRadius* cos(6 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 6   
        midRadius* sin(7 * angle), 0.5f, midRadius* cos(7 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 7  
        midRadius* sin(8 * angle), 0.5f, midRadius* cos(8 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 8  
        midRadius* sin(9 * angle), 0.5f, midRadius* cos(9 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 9  
        midRadius* sin(10 * angle), 0.5f, midRadius* cos(10 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 10   
        midRadius* sin(11 * angle), 0.5f, midRadius* cos(11 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 11  
        midRadius* sin(12 * angle), 0.5f, midRadius* cos(12 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 12  
        midRadius* sin(13 * angle), 0.5f, midRadius* cos(13 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 13  
        midRadius* sin(14 * angle), 0.5f, midRadius* cos(14 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 14   
        midRadius* sin(15 * angle), 0.5f, midRadius* cos(15 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 15  
        midRadius* sin(16 * angle), 0.5f, midRadius* cos(16 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 16  
        midRadius* sin(17 * angle), 0.5f, midRadius* cos(17 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 17   
        midRadius* sin(18 * angle), 0.5f, midRadius* cos(18 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 18  
        midRadius* sin(19 * angle), 0.5f, midRadius* cos(19 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 19  

        // bottom ring (y = -0.5f)
        midRadius* sin(0 * angle), -0.5f, midRadius* cos(0 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 20        
        midRadius* sin(1 * angle), -0.5f, midRadius* cos(1 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 21 
        midRadius* sin(2 * angle), -0.5f, midRadius* cos(2 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 22  
        midRadius* sin(3 * angle), -0.5f, midRadius* cos(3 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 23  
        midRadius* sin(4 * angle), -0.5f, midRadius* cos(4 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 24    
        midRadius* sin(5 * angle), -0.5f, midRadius* cos(5 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 25   
        midRadius* sin(6 * angle), -0.5f, midRadius* cos(6 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 26   
        midRadius* sin(7 * angle), -0.5f, midRadius* cos(7 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 27  
        midRadius* sin(8 * angle), -0.5f, midRadius* cos(8 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 28  
        midRadius* sin(9 * angle), -0.5f, midRadius* cos(9 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 29  
        midRadius* sin(10 * angle), -0.5f, midRadius* cos(10 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 30   
        midRadius* sin(11 * angle), -0.5f, midRadius* cos(11 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 31  
        midRadius* sin(12 * angle), -0.5f, midRadius* cos(12 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 32  
        midRadius* sin(13 * angle), -0.5f, midRadius* cos(13 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 33  
        midRadius* sin(14 * angle), -0.5f, midRadius* cos(14 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 34   
        midRadius* sin(15 * angle), -0.5f, midRadius* cos(15 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 35  
        midRadius* sin(16 * angle), -0.5f, midRadius* cos(16 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 36  
        midRadius* sin(17 * angle), -0.5f, midRadius* cos(17 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 37   
        midRadius* sin(18 * angle), -0.5f, midRadius* cos(18 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 38  
        midRadius* sin(19 * angle), -0.5f, midRadius* cos(19 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 39 

        // top left ring (y = 0.15f)
        quartRadius* sin(0 * angle), 0.15f, quartRadius* cos(0 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 40        
        quartRadius* sin(1 * angle), 0.15f, quartRadius* cos(1 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 41 
        quartRadius* sin(2 * angle), 0.15f, quartRadius* cos(2 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 42  
        quartRadius* sin(3 * angle), 0.15f, quartRadius* cos(3 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 43  
        quartRadius* sin(4 * angle), 0.15f, quartRadius* cos(4 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 44    
        quartRadius* sin(5 * angle), 0.15f, quartRadius* cos(5 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 45   
        quartRadius* sin(6 * angle), 0.15f, quartRadius* cos(6 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 46   
        quartRadius* sin(7 * angle), 0.15f, quartRadius* cos(7 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 47  
        quartRadius* sin(8 * angle), 0.15f, quartRadius* cos(8 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 48  
        quartRadius* sin(9 * angle), 0.15f, quartRadius* cos(9 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 49  
        quartRadius* sin(10 * angle), 0.15f, quartRadius* cos(10 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 50   
        quartRadius* sin(11 * angle), 0.15f, quartRadius* cos(11 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 51  
        quartRadius* sin(12 * angle), 0.15f, quartRadius* cos(12 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 52  
        quartRadius* sin(13 * angle), 0.15f, quartRadius* cos(13 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 53  
        quartRadius* sin(14 * angle), 0.15f, quartRadius* cos(14 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 54   
        quartRadius* sin(15 * angle), 0.15f, quartRadius* cos(15 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 55  
        quartRadius* sin(16 * angle), 0.15f, quartRadius* cos(16 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 56  
        quartRadius* sin(17 * angle), 0.15f, quartRadius* cos(17 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 57   
        quartRadius* sin(18 * angle), 0.15f, quartRadius* cos(18 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 58  
        quartRadius* sin(19 * angle), 0.15f, quartRadius* cos(19 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 59  

        // bottom left ring (y = -0.15f)
        quartRadius* sin(0 * angle), -0.15f, quartRadius* cos(0 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 60        
        quartRadius* sin(1 * angle), -0.15f, quartRadius* cos(1 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 61 
        quartRadius* sin(2 * angle), -0.15f, quartRadius* cos(2 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 62  
        quartRadius* sin(3 * angle), -0.15f, quartRadius* cos(3 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 63  
        quartRadius* sin(4 * angle), -0.15f, quartRadius* cos(4 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 64    
        quartRadius* sin(5 * angle), -0.15f, quartRadius* cos(5 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 65   
        quartRadius* sin(6 * angle), -0.15f, quartRadius* cos(6 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 66   
        quartRadius* sin(7 * angle), -0.15f, quartRadius* cos(7 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 67  
        quartRadius* sin(8 * angle), -0.15f, quartRadius* cos(8 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 68  
        quartRadius* sin(9 * angle), -0.15f, quartRadius* cos(9 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 69  
        quartRadius* sin(10 * angle), -0.15f, quartRadius* cos(10 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 70   
        quartRadius* sin(11 * angle), -0.15f, quartRadius* cos(11 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 71  
        quartRadius* sin(12 * angle), -0.15f, quartRadius* cos(12 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 72  
        quartRadius* sin(13 * angle), -0.15f, quartRadius* cos(13 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 73  
        quartRadius* sin(14 * angle), -0.15f, quartRadius* cos(14 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 74   
        quartRadius* sin(15 * angle), -0.15f, quartRadius* cos(15 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 75  
        quartRadius* sin(16 * angle), -0.15f, quartRadius* cos(16 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 76  
        quartRadius* sin(17 * angle), -0.15f, quartRadius* cos(17 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 77   
        quartRadius* sin(18 * angle), -0.15f, quartRadius* cos(18 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 78  
        quartRadius* sin(19 * angle), -0.15f, quartRadius* cos(19 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 79  

        // top right ring (y = 0.15f)
        radius * sin(0 * angle), 0.15f, radius * cos(0 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 80        
        radius * sin(1 * angle), 0.15f, radius * cos(1 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 81 
        radius * sin(2 * angle), 0.15f, radius * cos(2 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 82  
        radius * sin(3 * angle), 0.15f, radius * cos(3 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 83  
        radius * sin(4 * angle), 0.15f, radius * cos(4 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 84    
        radius * sin(5 * angle), 0.15f, radius * cos(5 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 85   
        radius * sin(6 * angle), 0.15f, radius * cos(6 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 86   
        radius * sin(7 * angle), 0.15f, radius * cos(7 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 87  
        radius * sin(8 * angle), 0.15f, radius * cos(8 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 88  
        radius * sin(9 * angle), 0.15f, radius * cos(9 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 89  
        radius * sin(10 * angle), 0.15f, radius * cos(10 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 90   
        radius * sin(11 * angle), 0.15f, radius * cos(11 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 91  
        radius * sin(12 * angle), 0.15f, radius * cos(12 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 92  
        radius * sin(13 * angle), 0.15f, radius * cos(13 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 93  
        radius * sin(14 * angle), 0.15f, radius * cos(14 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 94   
        radius * sin(15 * angle), 0.15f, radius * cos(15 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 95  
        radius * sin(16 * angle), 0.15f, radius * cos(16 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 96  
        radius * sin(17 * angle), 0.15f, radius * cos(17 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 97   
        radius * sin(18 * angle), 0.15f, radius * cos(18 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 98  
        radius * sin(19 * angle), 0.15f, radius * cos(19 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 99  
 
        // bottom right ring (y = -0.5f)
        radius * sin(0 * angle), -0.15f, radius * cos(0 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 100        
        radius * sin(1 * angle), -0.15f, radius * cos(1 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 101 
        radius * sin(2 * angle), -0.15f, radius * cos(2 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 102  
        radius * sin(3 * angle), -0.15f, radius * cos(3 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 103  
        radius * sin(4 * angle), -0.15f, radius * cos(4 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 104    
        radius * sin(5 * angle), -0.15f, radius * cos(5 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 105   
        radius * sin(6 * angle), -0.15f, radius * cos(6 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 106   
        radius * sin(7 * angle), -0.15f, radius * cos(7 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 107  
        radius * sin(8 * angle), -0.15f, radius * cos(8 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 108  
        radius * sin(9 * angle), -0.15f, radius * cos(9 * angle),    1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 109  
        radius * sin(10 * angle), -0.15f, radius * cos(10 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 110   
        radius * sin(11 * angle), -0.15f, radius * cos(11 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 111  
        radius * sin(12 * angle), -0.15f, radius * cos(12 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 112  
        radius * sin(13 * angle), -0.15f, radius * cos(13 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 113  
        radius * sin(14 * angle), -0.15f, radius * cos(14 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 114   
        radius * sin(15 * angle), -0.15f, radius * cos(15 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 115  
        radius * sin(16 * angle), -0.15f, radius * cos(16 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 116  
        radius * sin(17 * angle), -0.15f, radius * cos(17 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,  // vertex 117   
        radius * sin(18 * angle), -0.15f, radius * cos(18 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0,   // vertex 118  
        radius * sin(19 * angle), -0.15f, radius * cos(19 * angle),  1.0f, 1.0f, 1.0f, alpha,  0.0, 0.0  // vertex 119  
    };

    unsigned int torusIndices[] = {
        // top to top right
        0, 80, 81,
        0, 1, 81,
        1, 81, 82,
        1, 2, 82,
        2, 82, 83,
        2, 3, 83,
        3, 83, 84,
        3, 4, 84,
        4, 84, 85,
        4, 5, 85,
        5, 85, 86,
        5, 6, 86,
        6, 86, 87,
        6, 7, 87,
        7, 87, 88,
        7, 8, 88,
        8, 88, 89,
        8, 9, 89,
        9, 89, 90,
        9, 10, 90,
        10, 90, 91,
        10, 11, 91,
        11, 91, 92,
        11, 12, 92,
        12, 92, 93,
        12, 13, 93,
        13, 93, 94,
        13, 14, 94,
        14, 94, 95,
        14, 15, 95,
        15, 95, 96,
        15, 16, 96,
        16, 96, 97,
        16, 17, 97,
        17, 97, 98,
        17, 18, 98,
        18, 98, 99,
        18, 19, 99,
        19, 99, 80,
        19, 0, 80,
       
        // top to top left
        0, 40, 41,
        0, 1, 41,
        1, 41, 42,
        1, 2, 42,
        2, 42, 43,
        2, 3, 43,
        3, 43, 44,
        3, 4, 44,
        4, 44, 45,
        4, 5, 45,
        5, 45, 46,
        5, 6, 46,
        6, 46, 47,
        6, 7, 47,
        7, 47, 48,
        7, 8, 48,
        8, 48, 49,
        8, 9, 49,
        9, 49, 50,
        9, 10, 50,
        10, 50, 51,
        10, 11, 51,
        11, 51, 52,
        11, 12, 52,
        12, 52, 53,
        12, 13, 53,
        13, 53, 54,
        13, 14, 54,
        14, 54, 55,
        14, 15, 55,
        15, 55, 56,
        15, 16, 56,
        16, 56, 57,
        16, 17, 57,
        17, 57, 58,
        17, 18, 58,
        18, 58, 59,
        18, 19, 59,
        19, 59, 40,
        19, 0, 40,
        
        // bottom to bottom right
        20, 100, 101,
        20, 21, 101,
        21, 101, 102,
        21, 22, 102,
        22, 102, 103,
        22, 23, 103,
        23, 103, 104,
        23, 24, 104,
        24, 104, 105,
        24, 25, 105,
        25, 105, 106,
        25, 26, 106,
        26, 106, 107,
        26, 27, 107,
        27, 107, 108,
        27, 28, 108,
        28, 108, 109,
        28, 29, 109,
        29, 109, 110,
        29, 30, 110,
        30, 110, 111,
        30, 31, 111,
        31, 111, 112,
        31, 32, 112,
        32, 112, 113,
        32, 33, 113,
        33, 113, 114,
        33, 34, 114,
        34, 114, 115,
        34, 35, 115,
        35, 115, 116,
        35, 36, 116,
        36, 116, 117,
        36, 37, 117,
        37, 117, 118,
        37, 38, 118,
        38, 118, 119,
        38, 39, 119,
        39, 119, 100,
        39, 20, 100,

        // bottom to bottem left
        20, 60, 61,
        20, 21, 61,
        21, 61, 62,
        21, 22, 62,
        22, 62, 63,
        22, 23, 63,
        23, 63, 64,
        23, 24, 64,
        24, 64, 65,
        24, 25, 65,
        25, 65, 66,
        25, 26, 66,
        26, 66, 67,
        26, 27, 67,
        27, 67, 68,
        27, 28, 68,
        28, 68, 69,
        28, 29, 69,
        29, 69, 70,
        29, 30, 70,
        30, 70, 71,
        30, 31, 71,
        31, 71, 72,
        31, 32, 72,
        32, 72, 73,
        32, 33, 73,
        33, 73, 74,
        33, 34, 74,
        34, 74, 75,
        34, 35, 75,
        35, 75, 76,
        35, 36, 76,
        36, 76, 77,
        36, 37, 77,
        37, 77, 78,
        37, 38, 78,
        38, 78, 79,
        38, 39, 79,
        39, 79, 60,
        39, 20, 60,

        // top right to bottom right
        80, 100, 101,
        80, 81, 101,
        81, 101, 102,
        81, 82, 102,
        82, 102, 103,
        82, 83, 103,
        83, 103, 104,
        83, 84, 104,
        84, 104, 105,
        84, 85, 105,
        85, 105, 106,
        85, 86, 106,
        86, 106, 107,
        86, 87, 107,
        87, 107, 108,
        87, 88, 108,
        88, 108, 109,
        88, 89, 109,
        89, 109, 110,
        89, 90, 110,
        90, 110, 111,
        90, 91, 111,
        91, 111, 112,
        91, 92, 112,
        92, 112, 113,
        92, 93, 113,
        93, 113, 114,
        93, 94, 114,
        94, 114, 115,
        94, 95, 115,
        95, 115, 116,
        95, 96, 116,
        96, 116, 117,
        96, 97, 117,
        97, 117, 118,
        97, 98, 118,
        98, 118, 119,
        98, 99, 119,
        99, 119, 100,
        99, 80, 100,

        // top left to bottom left
        40, 60, 61,
        40, 41, 61,
        41, 61, 62,
        41, 42, 62,
        42, 62, 63,
        42, 43, 63,
        43, 63, 64,
        43, 44, 64,
        44, 64, 65,
        44, 45, 65,
        45, 65, 66,
        45, 46, 66,
        46, 66, 67,
        46, 47, 67,
        47, 67, 68,
        47, 48, 68,
        48, 68, 69,
        48, 49, 69,
        49, 69, 70,
        49, 50, 70,
        50, 70, 71,
        50, 51, 71,
        51, 71, 72,
        51, 52, 72,
        52, 72, 73,
        52, 53, 73,
        53, 73, 74,
        53, 54, 74,
        54, 74, 75,
        54, 55, 75,
        55, 75, 76,
        55, 56, 76,
        56, 76, 77,
        56, 57, 77,
        57, 77, 78,
        57, 58, 78,
        58, 78, 79,
        58, 59, 79,
        59, 79, 60,
        59, 40, 60
    };

    unsigned int torusVBO, torusVAO, torusEBO;
    glGenVertexArrays(1, &torusVAO);
    glGenBuffers(1, &torusVBO);
    glGenBuffers(1, &torusEBO);

    glBindVertexArray(torusVAO);

    glBindBuffer(GL_ARRAY_BUFFER, torusVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(torusVertices), torusVertices, GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, torusEBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(torusIndices), torusIndices, GL_STATIC_DRAW);

    // torus vertex pointer
    // position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 9 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    // color attribute
    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 9 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    // texture attribute
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 9 * sizeof(float), (void*)(7 * sizeof(float)));
    glEnableVertexAttribArray(2);

    // define cube stand vertices and indices  
    float standVertices[] = {  
        // positions       // color rgba              // tex coords
        //
        // top rectangle (y = .5f)
        -0.3f, 0.0f, 0.3f,    1.0f, 1.0f, 1.0f, 1.0f,  0.0, 0.0,  // vertex 0
        0.3f, 0.0f, 0.3f,     1.0f, 1.0f, 1.0f, 1.0f,  1.0, 0.0,  // vertex 1
        0.3f, 0.0f, -0.3f,    1.0f, 1.0f, 1.0f, 1.0f,  0.0, 0.0,  // vertex 2
        -0.3f, 0.0f, -0.3f,   1.0f, 1.0f, 1.0f, 1.0f,  1.0, 0.0,  // vertex 3
        
        // bottom rectangle (y = -.5f)
        -0.5f, -0.5f, 0.5f,   1.0f, 1.0f, 1.0f, 1.0f,  0.0, 1.0,  // vertex 4
        0.5f, -0.5f, 0.5f,    1.0f, 1.0f, 1.0f, 1.0f,  1.0, 1.0,  // vertex 5
        0.5f, -0.5f, -0.5f,   1.0f, 1.0f, 1.0f, 1.0f,  0.0, 1.0,  // vertex 6
        -0.5f, -0.5f, -0.5f,  1.0f, 1.0f, 1.0f, 1.0f,  1.0, 1.0   // vertex 7
    };
    unsigned int standIndices[] = {
        // bottom base connections
        4, 5, 6,
        6, 7, 4,

        // top base connections
        0, 1, 2,
        2, 3, 0,

        // top to bottom face connections
        0, 4, 5,
        0, 1, 5,
        1, 5, 6,
        1, 2, 6,
        2, 6, 7,
        2, 3, 7,
        3, 7, 4,
        3, 0, 4
    };
    unsigned int standVBO, standVAO, standEBO;
    glGenVertexArrays(1, &standVAO);
    glGenBuffers(1, &standVBO);
    glGenBuffers(1, &standEBO);

    glBindVertexArray(standVAO);

    glBindBuffer(GL_ARRAY_BUFFER, standVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(standVertices), standVertices, GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, standEBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(standIndices), standIndices, GL_STATIC_DRAW);
    
    // stand vertex pointer
    // position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 9 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    // color attribute
    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 9 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    // texture attribute
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 9 * sizeof(float), (void*)(7 * sizeof(float)));
    glEnableVertexAttribArray(2);

    // define cube book vertices and indices
    float bookVertices[] = {
        // positions         // color rgba            // tex coords       
        //
        // top rectangle (y = .5f)
        -0.5f, 0.5f, 0.5f,    0.6f, 0.6f, 0.6f, 1.0f,  0.0, 0.0,  // vertex 0
        0.5f, 0.5f, 0.5f,     0.6f, 0.6f, 0.6f, 1.0f,  1.0, 0.0,  // vertex 1
        0.5f, 0.5f, -0.5f,    0.6f, 0.6f, 0.6f, 1.0f,  0.0, 0.0,  // vertex 2
        -0.5f, 0.5f, -0.5f,   0.6f, 0.6f, 0.6f, 1.0f,  0.75, 0.0,  // vertex 3

        // bottom rectangle (y = -.5f)
        -0.5f, -0.5f, 0.5f,   0.6f, 0.6f, 0.6f, 1.0f,  0.0, 1.0,  // vertex 4
        0.5f, -0.5f, 0.5f,    0.6f, 0.6f, 0.6f, 1.0f,  1.0, 1.0,  // vertex 5
        0.5f, -0.5f, -0.5f,   0.6f, 0.6f, 0.6f, 1.0f,  0.0, 1.0,  // vertex 6
        -0.5f, -0.5f, -0.5f,  0.6f, 0.6f, 0.6f, 1.0f,  0.75, 1.0,   // vertex 7

        // extra for wrapping
        -0.5f, 0.5f, 0.5f,    0.6f, 0.6f, 0.6f, 1.0f,  1.0, 0.0,  // vertex 8
        -0.5f, -0.5f, 0.5f,   0.6f, 0.6f, 0.6f, 1.0f,  1.0, 1.0,  // vertex 9
        -0.5f, 0.5f, 0.5f,     0.6f, 0.6f, 0.6f, 1.0f,  1.0, 1.0,  // vertex 10
        -0.5f, 0.5f, -0.5f,    0.6f, 0.6f, 0.6f, 1.0f,  0.0, 1.0,  // vertex 11
    };
    unsigned int bookIndices[] = {
        // bottom base connections
        4, 5, 6,
        6, 7, 4,

        // top base connections
        1, 10, 11,
        1, 2, 11,

        // top to bottom face connections
        0, 4, 5,
        0, 1, 5,
        1, 5, 6,
        1, 2, 6,
        2, 6, 7,
        2, 3, 7,
        3, 7, 9,
        3, 8, 9
    };
    unsigned int bookVBO, bookVAO, bookEBO;
    glGenVertexArrays(1, &bookVAO);
    glGenBuffers(1, &bookVBO);
    glGenBuffers(1, &bookEBO);

    glBindVertexArray(bookVAO);

    glBindBuffer(GL_ARRAY_BUFFER, bookVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(bookVertices), bookVertices, GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, bookEBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(bookIndices), bookIndices, GL_STATIC_DRAW);

    // book vertex pointer
    // position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 9 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    // color attribute
    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 9 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    // texture attribute
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 9 * sizeof(float), (void*)(7 * sizeof(float)));
    glEnableVertexAttribArray(2);

    // define plane vertices and indices
    float planeVertices[] = {
        // positions         // color rgba            // tex coords
        -1.0f, 0.0f, -1.0f,  1.0f, 1.0f, 1.0f, 1.0f,  0.0, 0.0,  // bottom-left
         1.0f, 0.0f, -1.0f,  1.0f, 1.0f, 1.0f, 1.0f,  1.0, 0.0,  // bottom-right
         1.0f, 0.0f,  1.0f,  1.0f, 1.0f, 1.0f, 1.0f,  1.0, 1.0,  // top-right
        -1.0f, 0.0f,  1.0f,  1.0f, 1.0f, 1.0f, 1.0f,  0.0, 1.0   // top-left
    };

    unsigned int planeIndices[] = {
        0, 1, 2,
        0, 2, 3
    };

    unsigned int planeVAO, planeVBO, planeEBO;
    glGenVertexArrays(1, &planeVAO);
    glGenBuffers(1, &planeVBO);
    glGenBuffers(1, &planeEBO);

    glBindVertexArray(planeVAO);

    glBindBuffer(GL_ARRAY_BUFFER, planeVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(planeVertices), planeVertices, GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, planeEBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(planeIndices), planeIndices, GL_STATIC_DRAW);

    // plane vertex pointer
    // position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 9 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    // color attribute
    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 9 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    // texture attribute
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 9 * sizeof(float), (void*)(7 * sizeof(float)));
    glEnableVertexAttribArray(2);

    // define solar plane vertices and indices
    float solarVertices[] = {
        // positions            // color                 // tex coords
        -0.1f, 0.0f, -0.3f,     1.0f, 1.0f, 1.0f, 1.0f,  0.0, 0.0,  // bottom-left
         0.1f, 0.0f, -0.3f,     0.5f, 1.0f, 1.0f, 1.0f,  1.0, 0.0,  // bottom-right
         0.1f, 0.0f,  0.3f,     0.0f, 0.0f, 0.0f, 1.0f,  1.0, 1.0,  // top-right
        -0.1f, 0.0f,  0.3f,     0.5f, 1.0f, 0.5f, 1.0f,  0.0, 1.0   // top-left
    };

    unsigned int solarIndices[] = {
        0, 1, 2,
        0, 2, 3
    };

    unsigned int solarVAO, solarVBO, solarEBO;
    glGenVertexArrays(1, &solarVAO);
    glGenBuffers(1, &solarVBO);
    glGenBuffers(1, &solarEBO);

    glBindVertexArray(solarVAO);

    glBindBuffer(GL_ARRAY_BUFFER, solarVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(solarVertices), solarVertices, GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, solarEBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(solarIndices), solarIndices, GL_STATIC_DRAW);

    // plane vertex pointer
    // position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 9 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    // color attribute
    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 9 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    // texture attribute
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 9 * sizeof(float), (void*)(7 * sizeof(float)));
    glEnableVertexAttribArray(2);

    // second, configure the light's VAO (VBO stays the same; the vertices are the same
    unsigned int lightVAO;
    glGenVertexArrays(1, &lightVAO);
    glBindVertexArray(lightVAO);

    glBindBuffer(GL_ARRAY_BUFFER, solarVBO);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, solarEBO);
    // note that we update the lamp's position attribute's stride to reflect the updated buffer data
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 9 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    // * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
    // 
    // load and create a texture 
    // -------------------------
    unsigned int tableMap = loadTexture("image-from-rawpixel-id-5960780-jpeg.jpg");
    unsigned int sphereMap = loadTexture("image-from-rawpixel-id-6038748-jpeg.jpg");
    unsigned int bookCoverMap = loadTexture("wallpaperuse.com-game-of-thrones-wallpaper-12301.jpg");
    unsigned int bookSpineMap = loadTexture("kaleidoscope-s-4soebUqIU-unsplash.jpg");
    unsigned int bookBackMap = loadTexture("mauricio-santos-N1gFsYf9AI0-unsplash.jpg");
    unsigned int prismMap1 = loadTexture("image-from-rawpixel-id-8627219-jpeg.jpg");
    unsigned int prismMap2 = loadTexture("image-from-rawpixel-id-11902134-jpeg.jpg");
    unsigned int standMap = loadTexture("image-from-rawpixel-id-5925323-jpeg.jpg");
    unsigned int solarMap2 = loadTexture("image-from-rawpixel-id-5962162-original.jpg");
    unsigned int solarMap1 = loadTexture("image-from-rawpixel-id-5947148-jpeg.jpg");
    unsigned int cylinderMap = loadTexture("image-from-rawpixel-id-5925323-jpeg.jpg");
    unsigned int plateMap = loadTexture("image-from-rawpixel-id-6129180-jpeg.jpg");
    unsigned int candleMap = loadTexture("image-from-rawpixel-id-2706861-jpeg.jpg");
    unsigned int candleLidMap = loadTexture("katie-harp-oZgj_nQQvuo-unsplash.jpg");
    ourShader.use();
    ourShader.setInt("texture1", 0);
    ourShader.setInt("texture2", 1);
    
    // * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
    // enable wireframe mode
    //glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

    // render loop
    // -----------
    while (!glfwWindowShouldClose(window))
    {
        // per-frame time logic
        // --------------------
        float currentFrame = static_cast<float>(glfwGetTime());
        deltaTime = currentFrame - lastFrame;
        lastFrame = currentFrame;

        // input
        // -----
        processInput(window);

        // render
        // ------
        glClearColor(0.5f, 0.5f, 0.5f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        ourShader.use();
        glm::mat4 projection;

        if (isPerspective)
        {
            projection = glm::perspective(glm::radians(70.0f), (float)SCR_WIDTH / (float)SCR_HEIGHT, 0.1f, 100.0f);
            ourShader.setMat4("projection", projection);
        }
        else
        {
            projection = glm::ortho(-5.0f, 5.0f, -5.0f, 5.0f, 0.1f, 100.0f);
            ourShader.setMat4("projection", projection);
        }

        if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
        {
            isPerspective = !isPerspective;  // Toggle between perspective and orthographic
        }

        // camera/view transformation
        glm::mat4 view = camera.GetViewMatrix();
        ourShader.setMat4("view", view);

        // create transformations for prism
        glm::mat4 model = glm::mat4(1.0f); 
        // translate the model to move it back and to the right
        model = glm::translate(model, glm::vec3(3.5f, 0.75f, -2.0f));
        //scale the model to make it smaller
        model = glm::scale(model, glm::vec3(0.7f, 0.7f, 0.7f));
        // rotate model 
        model = glm::rotate(model, glm::radians(45.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        ourShader.setMat4("model", model); // Send model matrix to shader

        ourShader.setVec3("objectColor", 1.0f, 1.0f, 1.0f);
        // front left light yellow key light
        ourShader.setVec3("lightColor", 1.0f, 1.0f, 0.7f);
        ourShader.setVec3("lightPos", -4.0f, 10.0f, -2.0f);
        // back right light yellow fill light
        ourShader.setVec3("lightColor2", 1.0f, 1.0f, 0.7f);
        ourShader.setVec3("lightPos2", 6.0f, 10.0f, -2.0f);
        ourShader.setVec3("viewPosition", camera.Position);
        ourShader.setVec2("uvScale", uvScale);

        // bind prism textures
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, prismMap1);
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, prismMap2);
        ourShader.setBool("multipleTextures", multiple);

        // render container
        glBindVertexArray(VAO);
        glDrawElements(GL_TRIANGLES, 72, GL_UNSIGNED_INT, 0); // 3 vertices times 24 triangles
        glBindTexture(GL_TEXTURE_2D, 0);
        glBindTexture(GL_TEXTURE_2D, 1);
        ourShader.setInt("texture1", 0);
        ourShader.setInt("texture2", 1);
        ourShader.setBool("multipleTextures", !multiple);

        // draw lamps
        // -----
        // also draw the lamp object 1
        lightShader.use();
        lightShader.setMat4("projection", projection);
        lightShader.setMat4("view", view);
        model = glm::mat4(1.0f);
        model = glm::translate(model, glm::vec3(-4.0f, 10.0f, -2.0f));
        model = glm::scale(model, glm::vec3(6.0f, 1.0f, 3.0f));
        lightShader.setMat4("model", model);

        glBindVertexArray(lightVAO);
        glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);

        // also draw the lamp object 2
        lightShader.use();
        lightShader.setMat4("projection", projection);
        lightShader.setMat4("view", view);
        model = glm::mat4(1.0f);
        model = glm::translate(model, glm::vec3(6.0f, 10.0f, -2.0f));
        model = glm::scale(model, glm::vec3(6.0f, 1.0f, 3.0f));
        lightShader.setMat4("model", model);

        glBindVertexArray(lightVAO);
        glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);

        ourShader.use();

        // create transformations for stand
        glm::mat4 modelStand = glm::mat4(1.0f); 
        // translate the model to move it back and to the right
        modelStand = glm::translate(modelStand, glm::vec3(3.5f, 0.25f, -2.0f));
        // scale the model to make it wider
        modelStand = glm::scale(modelStand, glm::vec3(1.25f, 0.5f, 1.25f));
        // rotate model
        modelStand = glm::rotate(modelStand, glm::radians(45.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        ourShader.setMat4("model", modelStand); // Send model matrix to shader

        // bind stand texture
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, standMap);

        // render container
        glBindVertexArray(standVAO);
        glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0); // 3 vertices times 12 triangles
        glBindTexture(GL_TEXTURE_2D, 0);

        // create transformations for book
        glm::mat4 modelBook = glm::mat4(1.0f);
        // translate the model to move it back and to the left
        modelBook = glm::translate(modelBook, glm::vec3(-2.2f, 1.2f, -4.0f));
        // rotate model
        modelBook = glm::rotate(modelBook, glm::radians(30.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        // scale the model to make it bigger
        modelBook = glm::scale(modelBook, glm::vec3(1.60f, 2.4f, 0.70f)); 
        ourShader.setMat4("model", modelBook); // Send model matrix to shader

        // bind book texture
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, bookCoverMap);

        // render container
        glBindVertexArray(bookVAO);
        glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0); // 3 vertices times 12 triangles
        glBindTexture(GL_TEXTURE_2D, 0);

        // create transformations for book back and side
        glm::mat4 modelBookBack = glm::mat4(1.0f);
        // translate the model to move it back and to the left
        modelBookBack = glm::translate(modelBookBack, glm::vec3(-2.201f, 1.2f, -4.001f));
        // rotate model
        modelBookBack = glm::rotate(modelBookBack, glm::radians(30.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        // scale the model to make it bigger
        modelBookBack = glm::scale(modelBookBack, glm::vec3(1.601f, 2.401f, 0.701f));
        ourShader.setMat4("model", modelBookBack); // Send model matrix to shader

        // bind book texture
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, bookBackMap);

        // render container
        glBindVertexArray(bookVAO);
        glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0); // 3 vertices times 12 triangles
        glBindTexture(GL_TEXTURE_2D, 0);

        // create transformations for book spine
        glm::mat4 modelBookSpine = glm::mat4(1.0f);
        // translate the model to move it back and to the left
        modelBookSpine = glm::translate(modelBookSpine, glm::vec3(-2.197f, 1.201f, -4.008f));
        // rotate model
        modelBookSpine = glm::rotate(modelBookSpine, glm::radians(30.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        // scale the model to make it bigger
        modelBookSpine = glm::scale(modelBookSpine, glm::vec3(1.59f, 2.401f, 0.69f));
        ourShader.setMat4("model", modelBookSpine); // Send model matrix to shader

        // bind book texture
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, bookSpineMap);

        // render container
        glBindVertexArray(bookVAO);
        glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0); // 3 vertices times 12 triangles
        glBindTexture(GL_TEXTURE_2D, 0);

        // create transformations for candle
        glm::mat4 modelCandle = glm::mat4(1.0f);
        // translate the model to move it back and to the right
        modelCandle = glm::translate(modelCandle, glm::vec3(1.6f, 0.8f, -3.75f));
        // scale the model to make it bigger
        modelCandle = glm::scale(modelCandle, glm::vec3(2.9f, 1.6f, 2.9f));
        // rotate model
        modelCandle = glm::rotate(modelCandle, glm::radians(35.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        ourShader.setMat4("model", modelCandle); // Send model matrix to shader

        // bind candle texture
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, candleMap);

        // render container
        glBindVertexArray(cylinderVAO);
        glDrawElements(GL_TRIANGLES, 240, GL_UNSIGNED_INT, 0); // 3 vertices times 80 triangles
        glBindTexture(GL_TEXTURE_2D, 0);
        
        // create transformations for candle lid
        glm::mat4 modelCandleLid = glm::mat4(1.0f);
        // translate the model to move it back and to the right
        modelCandleLid = glm::translate(modelCandleLid, glm::vec3(1.6f, 1.6f, -3.75f));
        // scale the model to make it bigger
        modelCandleLid = glm::scale(modelCandleLid, glm::vec3(3.1f, 0.05f, 3.1f));
        ourShader.setMat4("model", modelCandleLid); // Send model matrix to shader

        // bind candle texture
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, candleLidMap);

        // render container
        glBindVertexArray(cylinderVAO);
        glDrawElements(GL_TRIANGLES, 240, GL_UNSIGNED_INT, 0); // 3 vertices times 80 triangles
        glBindTexture(GL_TEXTURE_2D, 0);

        // create transformations for plate
        glm::mat4 modelPlate = glm::mat4(1.0f);
        // translate the model to move it back and to the right
        modelPlate = glm::translate(modelPlate, glm::vec3(3.5f, 0.385f, -2.0f));
        // scale the model to make it bigger
        modelPlate = glm::scale(modelPlate, glm::vec3(3.0f, 0.03f, 3.0f));
        ourShader.setMat4("model", modelPlate); // Send model matrix to shader

        // bind plate texture
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, plateMap);

        // render container
        glBindVertexArray(plateVAO);
        glDrawElements(GL_TRIANGLES, 240, GL_UNSIGNED_INT, 0); // 3 vertices times 80 triangles
        glBindTexture(GL_TEXTURE_2D, 0);

        // create transformations for stand cylinder
        glm::mat4 modelCylinder = glm::mat4(1.0f);
        // translate the model to move it back and to the right
        modelCylinder = glm::translate(modelCylinder, glm::vec3(3.5f, 0.3f, -2.0f));
        // scale the model to make it bigger
        modelCylinder = glm::scale(modelCylinder, glm::vec3(0.2f, 0.15f, 0.2f));
        ourShader.setMat4("model", modelCylinder); // Send model matrix to shader

        // bind stand cylinder texture
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, cylinderMap);

        // render container
        glBindVertexArray(cylinderVAO);
        glDrawElements(GL_TRIANGLES, 240, GL_UNSIGNED_INT, 0); // 3 vertices times 80 triangles
        glBindTexture(GL_TEXTURE_2D, 0);

        // create transformations for table 
        glm::mat4 modelPlane = glm::mat4(1.0f);
        // scale the model to make it wider and longer
        modelPlane = glm::scale(modelPlane, glm::vec3(4.9f, 1.0f, 3.5f));
        // translate the model to center it
        modelPlane = glm::translate(modelPlane, glm::vec3(0.1f, -0.001f, -0.6f));
        ourShader.setMat4("model", modelPlane); // Send model matrix to shader

        // bind table texture
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, tableMap);

        // render container
        glBindVertexArray(planeVAO);
        glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
        glBindTexture(GL_TEXTURE_2D, 0);

        // create transformations for solar
        glm::mat4 modelSolar = glm::mat4(1.0f);   
        // scale the model to make it wider and longer
        //modelSolar = glm::scale(modelSolar, glm::vec3(1.0f, 1.0f, 1.0f));
        // translate the model to center it on stand face
        modelSolar = glm::translate(modelSolar, glm::vec3(3.16f, 0.15f, -1.66f));
        // rotate model
        modelSolar = glm::rotate(modelSolar, glm::radians(45.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        modelSolar = glm::rotate(modelSolar, glm::radians(45.0f), glm::vec3(0.0f, 0.0f, 1.0f));
        ourShader.setMat4("model", modelSolar); // Send model matrix to shader

        // bind solar texture
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, solarMap1);
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, solarMap2);
        ourShader.setBool("multipleTextures", multiple);

        // render container
        glBindVertexArray(solarVAO);
        glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
        glBindTexture(GL_TEXTURE_2D, 0);
        glBindTexture(GL_TEXTURE_2D, 1);
        ourShader.setInt("texture1", 0);
        ourShader.setInt("texture2", 1);
        ourShader.setBool("multipleTextures", !multiple);

        // create transformations for sphere
        glm::mat4 modelSphere = glm::mat4(1.0f);
        // translate the model to move it back and to the right
        modelSphere = glm::translate(modelSphere, glm::vec3(-1.4f, 0.5f, -1.0f));
        modelSphere = glm::rotate(modelSphere, glm::radians(200.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        // scale the model to make it bigger
        //modelSphere = glm::scale(modelSphere, glm::vec3(3.1f, 0.05f, 3.1f));
        ourShader.setMat4("model", modelSphere); // Send model matrix to shader

        // bind sphere texture
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, sphereMap);

        // render container
        glBindVertexArray(sphereVAO);
        glDrawElements(GL_TRIANGLES, 720, GL_UNSIGNED_INT, 0); // 3 vertices times 240 triangles
        glBindTexture(GL_TEXTURE_2D, 0);

        // create transformations for torus
        glm::mat4 modelTorus = glm::mat4(1.0f);
        // translate the model to move it back and to the right
        modelTorus = glm::translate(modelTorus, glm::vec3(-1.4f, 1.05f, -1.0f));
        modelTorus = glm::rotate(modelTorus, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        // scale the model to make it bigger
        modelTorus = glm::scale(modelTorus, glm::vec3(0.1f, 0.05f, 0.1f));
        ourShader.setMat4("model", modelTorus); // Send model matrix to shader

        // bind torus texture
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, solarMap1);

        // render container
        glBindVertexArray(torusVAO);
        glDrawElements(GL_TRIANGLES, 720, GL_UNSIGNED_INT, 0); // 3 vertices times 240 triangles
        glBindTexture(GL_TEXTURE_2D, 0);
        
        // Disable wireframe mode (optional, as it will be automatically reset for the next frame)
        // glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

        // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
        // -------------------------------------------------------------------------------
        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    // optional: de-allocate all resources once they've outlived their purpose:
    // ------------------------------------------------------------------------
    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &VBO);
    glDeleteBuffers(1, &EBO);

    glDeleteVertexArrays(1, &planeVAO);
    glDeleteBuffers(1, &planeVBO);
    glDeleteBuffers(1, &planeEBO);

    glDeleteVertexArrays(1, &plateVAO);
    glDeleteBuffers(1, &plateVBO);
    glDeleteBuffers(1, &plateEBO);

    glDeleteVertexArrays(1, &standVAO);
    glDeleteBuffers(1, &standVBO);
    glDeleteBuffers(1, &standEBO);

    glDeleteVertexArrays(1, &bookVAO);
    glDeleteBuffers(1, &bookVBO);
    glDeleteBuffers(1, &bookEBO);

    glDeleteVertexArrays(1, &solarVAO);
    glDeleteBuffers(1, &solarVBO);
    glDeleteBuffers(1, &solarEBO);

    glDeleteVertexArrays(1, &cylinderVAO);
    glDeleteBuffers(1, &cylinderVBO);
    glDeleteBuffers(1, &cylinderEBO);

    glDeleteVertexArrays(1, &sphereVAO);
    glDeleteBuffers(1, &sphereVAO);
    glDeleteBuffers(1, &sphereVAO);

    glDeleteVertexArrays(1, &torusVAO);
    glDeleteBuffers(1, &torusVAO);
    glDeleteBuffers(1, &torusVAO);

    glDeleteVertexArrays(1, &lightVAO);

    // glfw: terminate, clearing all previously allocated GLFW resources.
    // ------------------------------------------------------------------
    glfwTerminate();
    return 0;
}

// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
// W = forward
// S = backward
// A = left
// D = right
// E = up
// Q = down
// ---------------------------------------------------------------------------------------------------------
void processInput(GLFWwindow* window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        camera.ProcessKeyboard(FORWARD, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        camera.ProcessKeyboard(BACKWARD, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        camera.ProcessKeyboard(LEFT, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        camera.ProcessKeyboard(RIGHT, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        camera.ProcessKeyboard(UP, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        camera.ProcessKeyboard(DOWN, deltaTime);  
}

// glfw: whenever the window size changed (by OS or user resize) this callback function executes
// ---------------------------------------------------------------------------------------------
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
    // make sure the viewport matches the new window dimensions; note that width and 
    // height will be significantly larger than specified on retina displays.
    glViewport(0, 0, width, height);
}

// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
    if (firstMouse)
    {
        lastX = xpos;
        lastY = ypos;
        firstMouse = false;
    }

    float xoffset = xpos - lastX;
    float yoffset = lastY - ypos; // reversed since y-coordinates go from bottom to top
    lastX = xpos;
    lastY = ypos;

    camera.ProcessMouseMovement(xoffset, yoffset);
}

// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// scroll upward = speed up
// scroll downward = slow down
// ----------------------------------------------------------------------
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
    camera.ProcessMouseScroll(yoffset);
}

// utility function for loading a 2D texture from file
// ---------------------------------------------------
unsigned int loadTexture(char const* path)
{
    unsigned int textureID;
    glGenTextures(1, &textureID);

    int width, height, nrComponents;
    unsigned char* data = stbi_load(path, &width, &height, &nrComponents, 0);
    if (data)
    {
        GLenum format;
        if (nrComponents == 1)
            format = GL_RED;
        else if (nrComponents == 3)
            format = GL_RGB;
        else if (nrComponents == 4)
            format = GL_RGBA;

        glBindTexture(GL_TEXTURE_2D, textureID);
        glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        stbi_image_free(data);
    }
    else
    {
        std::cout << "Texture failed to load at path: " << path << std::endl;
        stbi_image_free(data);
    }

    return textureID;
}