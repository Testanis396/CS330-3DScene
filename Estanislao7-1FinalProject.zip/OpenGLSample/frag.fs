#version 330 core
out vec4 FragColor;

in vec3 vFragPos;
in vec4 vColor; 
in vec2 vTexCoord;

// texture sampler
uniform sampler2D texture1;
uniform sampler2D texture2;
uniform bool multipleTextures;

uniform vec3 objectColor;
uniform vec3 lightColor;
uniform vec3 lightPos;
uniform vec3 lightColor2;
uniform vec3 lightPos2;
uniform vec3 viewPosition;
uniform vec2 uvScale;

void main()
{
    /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

    //Calculate Ambient lighting*/
    float ambientStrength = 0.2f; // Set ambient or global lighting strength
    vec3 ambient = ambientStrength * lightColor; // Generate ambient light color

    //Calculate Diffuse lighting*/
    vec3 norm = normalize(vColor.rgb); // Normalize vectors to 1 unit

    //Light 1
    vec3 lightDirection = normalize(lightPos - vFragPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
    float impact = max(dot(norm.rgb, lightDirection), 0.0); // Calculate diffuse impact by generating dot product of normal and light
    vec3 diffuse = impact * lightColor; // Generate diffuse light color

    //Light 2
    vec3 lightDirection2 = normalize(lightPos2 - vFragPos); 
    float impact2 = max(dot(norm.rgb, lightDirection2), 0.0);
    vec3 diffuse2 = impact2 * lightColor2; \

    //Calculate Specular lighting*/
    //Light 1 Key light 100% light yellow
    float specularIntensity = 1.0f; // Set specular light strength
    float highlightSize = 32.0f; // Set specular highlight size

    //Light 2 Key light 100% light yellow
    float specularIntensity2 = 1.0f; // Set specular light strength
    float highlightSize2 = 32.0f; // Set specular highlight size

    vec3 viewDir = normalize(viewPosition - vFragPos); // Calculate view direction

    //Light 1
    vec3 reflectDir = reflect(-lightDirection, norm.rgb);// Calculate reflection vector
       
    //Light 2
    vec3 reflectDir2 = reflect(-lightDirection2, norm.rgb);// Calculate reflection vector
        
    //Calculate specular component
    //Light 1
    float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
    vec3 specular = specularIntensity * specularComponent * lightColor;

    //Light 2
    float specularComponent2 = pow(max(dot(viewDir, reflectDir2), 0.0), highlightSize2);
    vec3 specular2 = specularIntensity2 * specularComponent2 * lightColor2;

    if (multipleTextures)
        {
            vec4 texColor1 = texture(texture1, vTexCoord * uvScale);
            vec4 texColor2 = texture(texture2, vTexCoord * uvScale);
            FragColor = mix(texColor1, texColor2, 0.5) * vec4(vColor); // Use the alpha from vColor
        }
    else 
        {
            // Texture holds the color to be used for all three components
            FragColor = texture(texture1,  vTexCoord * uvScale) * vec4(vColor);
        }
    
    vec4 phong = vec4((ambient + diffuse + specular), 1.0) * FragColor;
    vec4 phong2 = vec4((ambient + diffuse2 + specular2), 1.0) * FragColor;

    FragColor = (phong + phong2);
}